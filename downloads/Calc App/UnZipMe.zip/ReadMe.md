Copyright Jupiter090 All rights reserved

To open this application you need to have installed dotnet 5.0 -> https://dotnet.microsoft.com/en-us/download/dotnet