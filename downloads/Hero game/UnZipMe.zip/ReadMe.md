To run this game open game.exe file

If you cant run this file try install dotnet framework: https://dotnet.microsoft.com/download